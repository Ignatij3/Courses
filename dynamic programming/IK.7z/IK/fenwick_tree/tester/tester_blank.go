package main

import (
	"fmt"
	"math/rand"
	"time"
)

const (
	SIZE    = 1000
	N       = 10000
	MAX_NUM = 100000
)

type (
	testcase struct {
		data     []int
		requests []request
	}
	request struct {
		end int
	}
)

type fenwTree struct {
	data []int
}

func strip(n int) int {
	return n & (n + 1)
}

func newTree(data []int) *fenwTree {
	ftree := &fenwTree{
		data: append([]int{0}, data...),
	}

	ftree.fill()
	return ftree
}

func (ft *fenwTree) fill() {
	for i := 1; i < len(ft.data); i++ {
		ft.data[i] += ft.data[i-1]
	}
	for i := len(ft.data) - 1; i > 0; i-- {
		if strip(i) != 0 {
			ft.data[i] -= ft.data[strip(i)-1]
		}
	}
}

func (ft fenwTree) getsum(pos int) int {
	res := 0
	for ; pos > 0; pos = strip(pos) - 1 {
		res += ft.data[pos]
	}
	return res
}

func initData() []int {
	rand.Seed(time.Now().UnixNano())
	var size int = rand.Intn(SIZE) + 1

	arr := make([]int, size)
	for i := 0; i < size; i++ {
		arr[i] = rand.Intn(N)
	}

	return arr
}

func generateTestcase() testcase {
	test := testcase{
		data:     initData(),
		requests: make([]request, rand.Intn(SIZE)+1),
	}

	for i := range test.requests {
		test.requests[i] = request{
			end: rand.Intn(len(test.data)),
		}
	}

	return test
}

func smartTest(test testcase) []int {
	res := make([]int, len(test.requests))
	ftree := newTree(test.data)

	for i, req := range test.requests {
		res[i] = ftree.getsum(req.end)
	}

	return res
}

func stupidTest(test testcase) []int {
	res := make([]int, len(test.requests))

	for i, req := range test.requests {
		for j := 0; j < req.end; j++ {
			res[i] += test.data[j]
		}
	}

	return res
}

func compare(a, b []int) bool {
	if len(a) != len(b) {
		return false
	}

	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func main() {
	var (
		correct             bool
		resSmart, resStupid []int
	)

	for i := 0; i < N; i++ {
		test := generateTestcase()
		resSmart = smartTest(test)
		resStupid = stupidTest(test)
		correct = compare(resSmart, resStupid)

		if !correct {
			fmt.Printf("Error on test %d\n", i)
			fmt.Printf("test data: %v\nanswer: %v\nresult: %v\n\n", test.data, resStupid, resSmart)
			fmt.Println("requests:")
			for i, req := range test.requests {
				fmt.Printf("got [0; %d] - %d\n", req.end, resSmart[i])
				fmt.Printf("exp [0; %d] - %d\n", req.end, resStupid[i])
			}
			return
		}
	}
	fmt.Printf("All %d tests passed!", N)
}
