package main

import (
	"fmt"

	"cock/fenwick"
)

func retardedFunction(data []int, n int) int {
	res := 0
	for i := 0; i < n; i++ {
		res += data[i]
	}
	return res
}

func main() {
	data := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15}
	ftree := fenwick.NewTreeData(data)

	for i := range data {
		fmt.Printf("(%d) got: %d exp: %d\n", i, ftree.Sum(i), retardedFunction(data, i))
	}
}
