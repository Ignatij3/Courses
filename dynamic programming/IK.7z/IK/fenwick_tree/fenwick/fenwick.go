package fenwick

type fenwTree struct {
	data []int
}

func strip(n int) int {
	return n & (n + 1)
}

func NewTree(n int) *fenwTree {
	return NewTreeData(make([]int, n))
}

func NewTreeData(data []int) *fenwTree {
	ftree := &fenwTree{
		data: append([]int{}, data...),
	}

	ftree.fill()
	return ftree
}

func (ft *fenwTree) fill() {
	for i := len(ft.data) - 1; i >= 0; i-- {
		for j := strip(i); j < i; j++ {
			ft.data[i] += ft.data[j]
		}
	}
}

func (ft fenwTree) Sum(pos int) int {
	pos--
	res := 0
	for ; pos >= 0; pos = strip(pos) - 1 {
		res += ft.data[pos]
	}
	return res
}
