package main_test

import (
	"strconv"
	"sync"
	"testing"
)

const (
	thousand    = 1000
	million     = thousand * 1000
	CELL_COUNT  = 2236 //2236 ~= sqrt(5000000); 5000000 - кол-во обрабатываемых клеток в секунду
	MAX_WORKERS = 256
	MIN_WORKERS = 16
	CACHE_LIMIT = 1000
)

var (
	wg    sync.WaitGroup
	cache map[fraction][]int = make(map[fraction][]int)
)

type borders struct {
	xl, xr int
	yl, yr int
}

type worker struct {
	assignedRects []borders
}

type fraction struct {
	a, b int
}

func run(size, workers int, b *testing.B) {
	b.StopTimer()
	bounds := initBounds(size, workers)

	wrkrs := make([]worker, workers)
	for i := range wrkrs {
		wrkrs[i].assignedRects = make([]borders, 0)
	}

	if len(bounds) < len(wrkrs) {
		wrkrs = wrkrs[:len(bounds)]
	}

	for i, w := 0, 0; i < len(bounds); i, w = i+1, w+1 {
		if w == len(wrkrs) {
			w = 0
		}
		wrkrs[w].assignedRects = append(wrkrs[w].assignedRects, bounds[i])
	}

	weightArr := make([]map[int]int, workers)

	b.StartTimer()

	wg.Add(len(wrkrs))
	for i := range wrkrs {
		go func() { weightArr[i] = computations(wrkrs[i]) }()
	}
	wg.Wait()
}

func initBounds(size, workers int) []borders {
	cells := CELL_COUNT
	if size/cells < 1 {
		cells = size / 10
	}
	bounds := make([]borders, cells*cells)

	var (
		i, step int = 0, size / cells
		x, y    int = 1, 1
	)
	for x := 1; x < size-step; x += step {
		for y := 1; y < size-step; y += step {
			bounds[i] = borders{
				xl: x,
				xr: x + step,
				yl: y,
				yr: y + step,
			}
		}
		i++
	}

	bounds[i] = borders{
		xl: x,
		xr: size,
		yl: y,
		yr: size,
	}

	if i < len(bounds)-1 {
		bounds = bounds[:i]
	}

	return bounds
}

func initCache() {
	for a := 1; a < CACHE_LIMIT; a++ {
		for b := 1; b < CACHE_LIMIT; b++ {
			cache[fraction{a, b}] = getContinuedFrac(fraction{a, b})
		}
	}
}

func computations(wrk worker) map[int]int {
	weights := make(map[int]int)
	f := fraction{1, 1}

	for _, rect := range wrk.assignedRects {
		for f.a = rect.xl; f.a <= rect.xr; f.a++ {
			for f.b = rect.yl; f.b <= rect.yr; f.b++ {
				for _, num := range getContinuedFrac(f) {
					weights[num]++
				}
			}
		}
	}
	wg.Done()
	return weights
}

func getContinuedFrac(f fraction) []int {
	var contFrac []int = make([]int, 0)
	for f.b > 0 {
		contFrac = append(contFrac, f.a/f.b)
		f.a, f.b = f.b, f.a%f.b
		if _, ok := cache[f]; ok {
			return append(contFrac, cache[f]...)
		}
	}
	return contFrac
}

func BenchmarkConcurrent(b *testing.B) {
	var testset = []struct {
		name string
		size int
	}{
		{
			name: "1e2",
			size: thousand / 10,
		},
		{
			name: "1e3",
			size: thousand,
		},
		{
			name: "1e4",
			size: thousand * 10,
		},
		{
			name: "1e5",
			size: thousand * 100,
		},
		{
			name: "1e6",
			size: million,
		},
		{
			name: "1e7",
			size: million * 10,
		},
	}

	for _, test := range testset {
		for workers := MAX_WORKERS; workers >= MIN_WORKERS; workers /= 2 {
			name := test.name + "w" + strconv.Itoa(workers)

			b.Run(name, func(b *testing.B) {
				for i := 0; i < b.N; i++ {
					run(test.size, workers, b)
				}
			})
		}
	}
}
