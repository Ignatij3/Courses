package main

import (
	"fmt"
	"log"
	"os"
	"sync"
	"time"
)

const (
	SIZE = 10000
)

var (
	CELL_COUNT int = 1000
	WORKERS    int = 100
	CHANGE     int = 1
)

var (
	wg     sync.WaitGroup
	fileio sync.Mutex
)

type borders struct {
	xl, xr int
	yl, yr int
}

type worker struct {
	assignedRects []borders
}

func run() {
	bounds := initBounds()

	wrkrs := make([]worker, WORKERS)
	for i := range wrkrs {
		wrkrs[i].assignedRects = make([]borders, 0)
	}

	if len(bounds) < len(wrkrs) {
		wrkrs = wrkrs[:len(bounds)]
	}

	for i, w := 0, 0; i < len(bounds); i, w = i+1, w+1 {
		if w == len(wrkrs) {
			w = 0
		}
		wrkrs[w].assignedRects = append(wrkrs[w].assignedRects, bounds[i])
	}

	weightArr := make([]map[int]int, WORKERS)

	wg.Add(len(wrkrs))
	for i := range wrkrs {
		go func() { weightArr[i] = computations(wrkrs[i]) }()
	}
	wg.Wait()
}

func initBounds() []borders {
	cells := CELL_COUNT
	if SIZE/cells < 1 {
		cells = SIZE / 10
	}
	bounds := make([]borders, cells*cells)

	var (
		i, step int = 0, SIZE / cells
		x, y    int = 1, 1
	)
	for x := 1; x < SIZE-step; x += step {
		for y := 1; y < SIZE-step; y += step {
			bounds[i] = borders{
				xl: x,
				xr: x + step,
				yl: y,
				yr: y + step,
			}
		}
		i++
	}

	bounds[i] = borders{
		xl: x,
		xr: SIZE,
		yl: y,
		yr: SIZE,
	}

	if i < len(bounds)-1 {
		bounds = bounds[:i]
	}

	return bounds
}

func computations(wrk worker) map[int]int {
	weights := make(map[int]int)
	for _, rect := range wrk.assignedRects {
		for a := rect.xl; a <= rect.xr; a++ {
			for b := rect.yl; b <= rect.yr; b++ {
				for _, num := range getContinuedFrac(a, b) {
					weights[num]++
				}
			}
		}
	}
	wg.Done()
	return weights
}

func getContinuedFrac(a, b int) []int {
	var contFrac []int = make([]int, 0)
	for b > 0 {
		contFrac = append(contFrac, a/b)
		a, b = b, a%b
	}
	return contFrac
}

func adjustVariables() {
	var (
		difference int64
		d1, d2     time.Duration
		st1, st2   time.Time
	)

	for {
		st1 = time.Now()
		run()
		d1 = time.Since(st1)

		WORKERS += CHANGE
		st2 = time.Now()
		run()
		d2 = time.Since(st2)

		difference = int64(d2 - d1)

	}
}

func saveResults() {
	fileio.Lock()
	out, err := os.Create("data.res")
	if err != nil {
		log.Fatal(err)
	}

	out.WriteString(fmt.Sprintf("cells: %d\nworkers: %d\n", CELL_COUNT, WORKERS))
	out.Close()
	fileio.Unlock()
}

func main() {
	adjustVariables()
	saveResults()
}
