package main

import (
	"bufio"
	"fmt"
	"os"
)

type flowmatrix [][]pipe

type pipe struct {
	capacity int
	flow     int
}

type network []*vertex

type vertex struct {
	conns       []*vertex
	visitedFrom *vertex
	visited     bool
}

func getData() network {
	var (
		vertices int
		pipes    int
	)

	reader := bufio.NewReader(os.Stdin)

	fmt.Fscanf(reader, "%d %d\n", &vertices, &pipes)

	start.visitedFrom = start

	net := make(network, vertices)

	var u, v, c int
	for i := 0; i < pipes; i++ {
		fmt.Fscanf(reader, "%d %d %d\n", &u, &v, &c)
		u--
		v--

		net[u].conns = append(net[u].conns)
	}

	ends.start = start
	ends.finish = finish

	return net
}

func main() {
	net := getData()
	res := calculate(net)
	fmt.Println(res)
}

func calculate(net network) int {
	bfs(ends.start, make([]*vertex, 0), ends.start.flow)
	return 0
}

func bfs(node *vertex, queue []*vertex, flow int) {
	if node.visited {
		return
	} else {
		node.visited = true
	}

	if node == ends.finish {
		setFlow(node.visitedFrom, node)
		return
	} else if len(queue) == 0 {
		return
	}

	for _, pipe := range pipes {

	}

	for _, next := range queue {
		next.visitedFrom = node
		bfs(next, queue, flow)
	}
}

func setFlow(node, prevnode *vertex) {
	if node == nil {
		return
	}
	node.flow = prevnode.flow
	setFlow(node.visitedFrom, node)
}
