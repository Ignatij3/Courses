package main

import (
	"encoding/json"
	"io"
	"log"
	"os"
)

type hockey struct {
	Date     date   `json:"Date"`
	Host     player `json:"Host"`
	Guest    player `json:"Guest"`
	Overtime bool   `json:"Overtime"`
}

type date struct {
	Year  int `json:"Year"`
	Month int `json:"Month"`
	Day   int `json:"Day"`
}

type player struct {
	Title string `json:"Title"`
	Goals int    `json:"Goals"`
}

func main() {
	log.SetFlags(log.Lshortfile)

	db, err := os.Open("hockey.json")
	if err != nil {
		log.Fatal(err)
	}

	decoder := json.NewDecoder(db)

	_, err = decoder.Token()
	if err != nil {
		log.Fatal(err)
	}

	var hk hockey
	for i := 0; decoder.More(); i++ {
		err = decoder.Decode(&hk)
		if err != nil {
			if unmarshalTypeErrorValue, ok := err.(*json.UnmarshalTypeError); ok {
				column := unmarshalTypeErrorValue.Offset
				log.Fatalf("Error when decoding json: SyntaxError at (%d;%d)\n%v", i, column, err)
			} else if err == io.EOF {
				break
			} else {
				log.Fatalf("%v\n%T", err, err)
			}
		}
	}

	_, err = decoder.Token()
	if err != nil {
		if err != io.EOF {
			log.Fatal(err)
		}
	}
}
