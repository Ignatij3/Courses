package main

import (
	"log"
	"os"
)

func main() {
	file, _ := os.Create(" ")
	log.SetOutput(file)
	log.SetPrefix("WHEN THE LOG IS SUS😳: ")
	log.SetFlags(log.Ldate | log.Ltime | log.Lmicroseconds | log.Llongfile | log.Lshortfile | log.LUTC)

	log.Print("Fiera")
	log.Println("*Panicking*")
}
