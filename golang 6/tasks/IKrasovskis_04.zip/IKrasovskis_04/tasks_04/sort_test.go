package tasks04_test

import (
	"binheap"
	"math/rand"
	"testing"
)

func initArray1(size int, state string) []int {
	rand.Seed(16)
	arr := make([]int, size)

	if state == "AlmostSorted" {
		for i := 0; i < size; i++ {
			arr[i] = i - (size / 2)
		}

		randAmt := int(float64(size) * 0.05) //percentage of random elements, 0.05 means 5% of elements are randomised
		pl1, pl2 := 0, 0
		for i := 0; i < randAmt; i++ {
			pl1, pl2 = rand.Intn(size), rand.Intn(size)
			arr[pl1], arr[pl2] = arr[pl2], arr[pl1]
		}

	} else if state == "AlmostReverseSorted" {
		for i := size - 1; i >= 0; i-- {
			arr[i] = (size/2 - 1) - i
		}

		randAmt := int(float64(size) * 0.05) //percentage of random elements, 0.05 means 5% of elements are randomised
		pl1, pl2 := 0, 0
		for i := 0; i < randAmt; i++ {
			pl1, pl2 = rand.Intn(size), rand.Intn(size)
			arr[pl1], arr[pl2] = arr[pl2], arr[pl1]
		}

	} else {
		for i := 0; i < size; i++ {
			arr[i] = rand.Intn(size) - size/2
		}
	}

	return arr
}

const cutoff = 32

func qSort(c []int) {
	if len(c) <= cutoff {
		return
	}

	k := rand.Intn(len(c))
	c[0], c[k] = c[k], c[0]

	pivot := c[0]
	small, large := 1, len(c)-1
	for {
		for small < len(c) && c[small] < pivot {
			small++
		}
		for pivot < c[large] {
			large--
		}
		if small >= large {
			break
		}
		c[small], c[large] = c[large], c[small]
		small++
		large--
	}

	c[0], c[large] = c[large], c[0]
	qSort(c[:large])
	qSort(c[large+1:])
}

func quickSort(c []int) {
	qSort(c)
	for i, x := range c {
		j := i
		for j > 0 && x < c[j-1] {
			c[j] = c[j-1]
			j--
		}
		c[j] = x
	}
}

func heapSort(c []int) {
	var bheap binheap.BinaryHeap
	for _, x := range c {
		bheap.Add(binheap.Tdata(x))
	}
	for k := len(c) - 1; k >= 0; k-- {
		c[k] = int(bheap.ExtractMax())
	}
}

func binaryMergeSort(c []int) {
	var mid int
	for currSize := 1; currSize <= len(c)-1; currSize = 2 * currSize {
		for leftStart := 0; leftStart < len(c)-1; leftStart += 2 * currSize {
			mid = leftStart + currSize - 1
			if mid > len(c)-1 {
				mid = len(c) - 1
			}
			merge(c, mid+1)
		}
	}

	merge(c, len(c)/2)
}

func merge(c []int, start2 int) {
	res := make([]int, len(c))
	i1, i2, ires := 0, start2, 0

	for i1 < start2 && i2 < len(c) {
		if c[i1] < c[i2] {
			res[ires] = c[i1]
			i1++
		} else {
			res[ires] = c[i2]
			i2++
		}

		ires++
	}

	if i2 == len(c) {
		copy(c[ires:], c[i1:])
	}
	copy(c, res[:ires])
}

func naturalMergeSort(c []int) {
	start := []int{0}
	for i := 1; i < len(c); i++ {
		if c[i] < c[i-1] {
			start = append(start, i)
		}
	}

	start = append(start, len(c))
	for len(start) > 2 {
		for k := 0; k < len(start)-2; k += 2 {
			merge(c[start[k]:start[k+2]], start[k+1]-start[k])
		}

		k := 0
		for {
			k += 2
			if k >= len(start) {
				break
			}
			start[k/2] = start[k]
		}

		start = start[:k/2]
		if start[len(start)-1] < len(c) {
			start = append(start, len(c))
		}
	}
}

func Benchmark_QuickSort_RandomArray_1000(b *testing.B) {
	arr := initArray1(1000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSort(arr)
	}
}

func Benchmark_QuickSort_RandomArray_1000000(b *testing.B) {
	arr := initArray1(1000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSort(arr)
	}
}

func Benchmark_QuickSort_RandomArray_1000000000(b *testing.B) {
	arr := initArray1(1000000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSort(arr)
	}
}

func Benchmark_QuickSort_AlmostSortedArray_1000(b *testing.B) {
	arr := initArray1(1000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSort(arr)
	}
}

func Benchmark_QuickSort_AlmostSortedArray_1000000(b *testing.B) {
	arr := initArray1(1000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSort(arr)
	}
}

func Benchmark_QuickSort_AlmostSortedArray_1000000000(b *testing.B) {
	arr := initArray1(1000000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSort(arr)
	}
}

func Benchmark_QuickSort_AlmostReverseSortedArray_1000(b *testing.B) {
	arr := initArray1(1000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSort(arr)
	}
}

func Benchmark_QuickSort_AlmostReverseSortedArray_1000000(b *testing.B) {
	arr := initArray1(1000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSort(arr)
	}
}

func Benchmark_QuickSort_AlmostReverseSortedArray_1000000000(b *testing.B) {
	arr := initArray1(1000000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSort(arr)
	}
}

func Benchmark_BinaryMergeSort_RandomArray_1000(b *testing.B) {
	arr := initArray1(1000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		binaryMergeSort(arr)
	}
}

func Benchmark_BinaryMergeSort_RandomArray_1000000(b *testing.B) {
	arr := initArray1(1000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		binaryMergeSort(arr)
	}
}

func Benchmark_BinaryMergeSort_AlmostSortedArray_1000(b *testing.B) {
	arr := initArray1(1000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		binaryMergeSort(arr)
	}
}

func Benchmark_BinaryMergeSort_AlmostSortedArray_1000000(b *testing.B) {
	arr := initArray1(1000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		binaryMergeSort(arr)
	}
}

func Benchmark_BinaryMergeSort_AlmostReverseSortedArray_1000(b *testing.B) {
	arr := initArray1(1000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		binaryMergeSort(arr)
	}
}

func Benchmark_BinaryMergeSort_AlmostReverseSortedArray_1000000(b *testing.B) {
	arr := initArray1(1000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		binaryMergeSort(arr)
	}
}

func Benchmark_NaturalMergeSort_RandomArray_1000(b *testing.B) {
	arr := initArray1(1000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		naturalMergeSort(arr)
	}
}

func Benchmark_NaturalMergeSort_RandomArray_1000000(b *testing.B) {
	arr := initArray1(1000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		naturalMergeSort(arr)
	}
}

func Benchmark_NaturalMergeSort_RandomArray_1000000000(b *testing.B) {
	arr := initArray1(1000000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		naturalMergeSort(arr)
	}
}

func Benchmark_NaturalMergeSort_AlmostSortedArray_1000(b *testing.B) {
	arr := initArray1(1000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		naturalMergeSort(arr)
	}
}

func Benchmark_NaturalMergeSort_AlmostSortedArray_1000000(b *testing.B) {
	arr := initArray1(1000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		naturalMergeSort(arr)
	}
}

func Benchmark_NaturalMergeSort_AlmostSortedArray_1000000000(b *testing.B) {
	arr := initArray1(1000000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		naturalMergeSort(arr)
	}
}

func Benchmark_NaturalMergeSort_AlmostReverseSortedArray_1000(b *testing.B) {
	arr := initArray1(1000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		naturalMergeSort(arr)
	}
}

func Benchmark_NaturalMergeSort_AlmostReverseSortedArray_1000000(b *testing.B) {
	arr := initArray1(1000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		naturalMergeSort(arr)
	}
}

func Benchmark_NaturalMergeSort_AlmostReverseSortedArray_1000000000(b *testing.B) {
	arr := initArray1(1000000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		naturalMergeSort(arr)
	}
}

func Benchmark_HeapSort_RandomArray_1000(b *testing.B) {
	arr := initArray1(1000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		heapSort(arr)
	}
}

func Benchmark_HeapSort_RandomArray_1000000(b *testing.B) {
	arr := initArray1(1000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		heapSort(arr)
	}
}

func Benchmark_HeapSort_RandomArray_1000000000(b *testing.B) {
	arr := initArray1(1000000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		heapSort(arr)
	}
}

func Benchmark_HeapSort_AlmostSortedArray_1000(b *testing.B) {
	arr := initArray1(1000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		heapSort(arr)
	}
}

func Benchmark_HeapSort_AlmostSortedArray_1000000(b *testing.B) {
	arr := initArray1(1000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		heapSort(arr)
	}
}

func Benchmark_HeapSort_AlmostSortedArray_1000000000(b *testing.B) {
	arr := initArray1(1000000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		heapSort(arr)
	}
}

func Benchmark_HeapSort_AlmostReverseSortedArray_1000(b *testing.B) {
	arr := initArray1(1000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		heapSort(arr)
	}
}

func Benchmark_HeapSort_AlmostReverseSortedArray_1000000(b *testing.B) {
	arr := initArray1(1000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		heapSort(arr)
	}
}

func Benchmark_HeapSort_AlmostReverseSortedArray_1000000000(b *testing.B) {
	arr := initArray1(1000000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		heapSort(arr)
	}
}
