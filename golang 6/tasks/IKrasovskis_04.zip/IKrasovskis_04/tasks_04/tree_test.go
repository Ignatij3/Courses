package tasks04_test

import (
	"fmt"
	"math/rand"
	"mypacks/order"
	"mypacks/order/avl"
	"mypacks/order/bst"
	"testing"
)

type integer int

func (i integer) Before(b order.Ordered) bool {
	return i < b.(integer)
}

func (i integer) Show() string {
	return fmt.Sprintf("%d", i)
}

func initArray(size int, state string) []integer {
	rand.Seed(16)
	arr := make([]integer, size)

	if state == "AlmostSorted" {
		for i := 0; i < size; i++ {
			arr[i] = integer(i - (size / 2))
		}

		randAmt := int(float64(size) * 0.05) //percentage of random elements, 0.05 means 5% of elements are randomised
		pl1, pl2 := 0, 0
		for i := 0; i < randAmt; i++ {
			pl1, pl2 = rand.Intn(size), rand.Intn(size)
			arr[pl1], arr[pl2] = arr[pl2], arr[pl1]
		}

	} else if state == "AlmostReverseSorted" {
		for i := size - 1; i >= 0; i-- {
			arr[i] = integer((size/2 - 1) - i)
		}

		randAmt := int(float64(size) * 0.05) //percentage of random elements, 0.05 means 5% of elements are randomised
		pl1, pl2 := 0, 0
		for i := 0; i < randAmt; i++ {
			pl1, pl2 = rand.Intn(size), rand.Intn(size)
			arr[pl1], arr[pl2] = arr[pl2], arr[pl1]
		}

	} else {
		for i := 0; i < size; i++ {
			arr[i] = integer(rand.Intn(size) - size/2)
		}
	}

	return arr
}

func Benchmark_BSTree_RandomArray_1000(b *testing.B) {
	var index int
	arr := initArray(1000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		tree := bst.NewTree()
		for _, val := range arr {
			tree.Insert(val)
		}

		tree.Traversal(order.InOrder, func(x order.Key) { arr[index] = x.(integer); index++ })
		index = 0
	}
}

func Benchmark_BSTree_RandomArray_1000000(b *testing.B) {
	var index int
	arr := initArray(1000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		tree := bst.NewTree()
		for _, val := range arr {
			tree.Insert(val)
		}

		tree.Traversal(order.InOrder, func(x order.Key) { arr[index] = x.(integer); index++ })
		index = 0
	}
}

func Benchmark_BSTree_AlmostSortedArray_1000(b *testing.B) {
	var index int
	arr := initArray(1000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		tree := bst.NewTree()
		for _, val := range arr {
			tree.Insert(val)
		}

		tree.Traversal(order.InOrder, func(x order.Key) { arr[index] = x.(integer); index++ })
		index = 0
	}
}

func Benchmark_BSTree_AlmostSortedArray_1000000(b *testing.B) {
	var index int
	arr := initArray(1000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		tree := bst.NewTree()
		for _, val := range arr {
			tree.Insert(val)
		}

		tree.Traversal(order.InOrder, func(x order.Key) { arr[index] = x.(integer); index++ })
		index = 0
	}
}

func Benchmark_BSTree_AlmostReverseSortedArray_1000(b *testing.B) {
	var index int
	arr := initArray(1000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		tree := bst.NewTree()
		for _, val := range arr {
			tree.Insert(val)
		}

		tree.Traversal(order.InOrder, func(x order.Key) { arr[index] = x.(integer); index++ })
		index = 0
	}
}

func Benchmark_BSTree_AlmostReverseSortedArray_1000000(b *testing.B) {
	var index int
	arr := initArray(1000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		tree := bst.NewTree()
		for _, val := range arr {
			tree.Insert(val)
		}

		tree.Traversal(order.InOrder, func(x order.Key) { arr[index] = x.(integer); index++ })
		index = 0
	}
}

func Benchmark_AVLTree_RandomArray_1000(b *testing.B) {
	var index int
	arr := initArray(1000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		tree := avl.NewAVLtree()
		for _, val := range arr {
			tree.Insert(val)
		}

		tree.Traversal(order.InOrder, func(x order.Key) { arr[index] = x.(integer); index++ })
		index = 0
	}
}

func Benchmark_AVLTree_AlmostSortedArray_1000(b *testing.B) {
	var index int
	arr := initArray(1000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		tree := avl.NewAVLtree()
		for _, val := range arr {
			tree.Insert(val)
		}

		tree.Traversal(order.InOrder, func(x order.Key) { arr[index] = x.(integer); index++ })
		index = 0
	}
}

func Benchmark_AVLTree_AlmostReverseSortedArray_1000(b *testing.B) {
	var index int
	arr := initArray(1000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		tree := avl.NewAVLtree()
		for _, val := range arr {
			tree.Insert(val)
		}

		tree.Traversal(order.InOrder, func(x order.Key) { arr[index] = x.(integer); index++ })
		index = 0
	}
}
