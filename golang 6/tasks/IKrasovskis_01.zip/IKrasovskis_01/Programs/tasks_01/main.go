package main

import (
	"fmt"

	"../../Packages/sorted"
	tpalias "../../Packages/typealiases"
)

func main() {
	var src sorted.Collection
	var intArr []tpalias.Integer = []tpalias.Integer{2, 1, 10, 2, 6, 8, 4, 2, 2, 2, 9, 11}

	//src = append(src, intArr...) //cannot use intArr (variable of type []typealiases.Integer) as []sorted.Ordered value in argument to append
	fmt.Printf("before sort: %v\n", intArr)
	for pos := range intArr {
		src.Insert(intArr[pos])
	}
	fmt.Printf("after sort: %v\n\n", src)

	if i, ok := src.First(tpalias.Integer(2)); ok {
		fmt.Printf("First 2 is in %d pos\n", i)
	} else {
		fmt.Println("2 was not found", i)
	}

	if i, ok := src.Last(tpalias.Integer(2)); ok {
		fmt.Printf("Last 2 is in %d pos\n", i)
	} else {
		fmt.Println("2 was not found", i)
	}

	if i, ok := src.Last(tpalias.Integer(7)); ok {
		fmt.Printf("Last 7 is in %d pos\n", i)
	} else {
		fmt.Println("7 was not found", i)
	}

	fmt.Printf("before: %v\n", src)

	src.DeleteFirst(tpalias.Integer(2))
	fmt.Printf("deleting left 2: %v\n", src)

	src.DeleteLast(tpalias.Integer(2))
	fmt.Printf("deleting right 2: %v\n", src)

	src.DeleteAll(tpalias.Integer(2))
	fmt.Printf("deleting all 2: %v\n", src)
}
