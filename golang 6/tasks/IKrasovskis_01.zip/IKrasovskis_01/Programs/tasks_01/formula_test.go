package main

import "testing"

func BenchmarkEdgeIf(b *testing.B) {
	var step int = 1
	for i := 0; i < b.N; i++ {
		if step >= 0 {
			step = 1
		} else {
			step = -1
		}
	}
}

func BenchmarkEdgeFormula(b *testing.B) {
	var step int = 1
	for i := 0; i < b.N; i++ {
		step = ((step|1)&(-1<<63) + (1<<62 - 1)) / 0x3FFFFFFFFFFFFFFF
	}
}
