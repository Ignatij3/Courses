package main

import (
	"math/rand"
	"testing"

	"../../Packages/sorted"
	tpalias "../../Packages/typealiases"
)

func initList(iterations int) []tpalias.Integer {
	rand.Seed(1)
	intList := make([]tpalias.Integer, iterations)
	for i := 0; i < iterations; i++ {
		intList[i] = tpalias.Integer(rand.Intn(100000))
	}

	return intList
}

func oldInsert(c *sorted.Collection, x sorted.Ordered) {
	*c = append(*c, x)
	i := len(*c) - 1

	for i > 0 && x.Before((*c)[i-1]) {
		i--
	}

	copy((*c)[i+1:], (*c)[i:])
	(*c)[i] = x
}

func insert(c *sorted.Collection, x sorted.Ordered) {
	left := 0
	mid := 0
	right := len(*c) - 1

	for left <= right {
		mid = (right + left) / 2

		if x.Before((*c)[mid]) {
			right = mid - 1
			if left > right {
				break
			}

		} else if (*c)[mid].Before(x) {
			left = mid + 1
			if left > right {
				mid++
				break
			}

		} else {
			break
		}
	}

	*c = append(*c, x)
	copy((*c)[mid+1:], (*c)[mid:])
	(*c)[mid] = x
}

func BenchmarkOldInsert(b *testing.B) {
	coll := make(sorted.Collection, 0)
	intList := initList(b.N)
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		oldInsert(&coll, intList[i])
	}
}

func BenchmarkInsert(b *testing.B) {
	coll := make(sorted.Collection, 0)
	intList := initList(b.N)
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		insert(&coll, intList[i])
	}
}
