package typealiases

import "../sorted"

//Integer is an alias for built-in type int
type Integer int

//Before returns whether a is less than b (of underlying type Integer)
func (a Integer) Before(b sorted.Ordered) bool {
	return a < b.(Integer)
}
