package sorted

import (
	"fmt"
)

//Ordered is an interface for managing sorted lists
type Ordered interface {
	Before(b Ordered) bool
}

//Collection is an alias to the type []Ordered
type Collection []Ordered

//OldInsert is like insert, but less effective
func (c *Collection) OldInsert(x Ordered) {
	*c = append(*c, x)
	i := len(*c) - 1

	for i > 0 && x.Before((*c)[i-1]) {
		i--
	}

	copy((*c)[i+1:], (*c)[i:])
	(*c)[i] = x
}

//Insert inserts new element into collection, using binary search
func (c *Collection) Insert(x Ordered) {
	left := 0
	mid := 0
	right := len(*c) - 1

	for left <= right {
		mid = (right + left) / 2

		if x.Before((*c)[mid]) {
			right = mid - 1
			if left > right {
				break
			}

		} else if (*c)[mid].Before(x) {
			left = mid + 1
			if left > right {
				mid++
				break
			}

		} else {
			break
		}
	}

	*c = append(*c, x)
	copy((*c)[mid+1:], (*c)[mid:])
	(*c)[mid] = x
}

//Find returns position of the found element to the one provided and whether it was found
func (c *Collection) Find(x Ordered) (int, bool) {
	left := 0
	mid := 0
	right := len(*c) - 1

	if len(*c) == 0 || x.Before((*c)[left]) || (*c)[right].Before(x) {
		return 0, false
	} else if (*c)[left] == x {
		return right, true
	}

	for left <= right {
		mid = (right + left) / 2

		if x.Before((*c)[mid]) {
			right = mid - 1

		} else if (*c)[mid].Before(x) {
			left = mid + 1

		} else {
			return mid, true
		}
	}

	return 0, false
}

//First returns position of the first found equivalent element to the one provided and whether it was found
func (c *Collection) First(x Ordered) (index int, detected bool) {
	return c.findEdge(x, -1)
}

//Last returns position of the last found equivalent element to the one provided and whether it was found
func (c *Collection) Last(x Ordered) (index int, detected bool) {
	return c.findEdge(x, 1)
}

//DeleteFirst deletes first occurence of x (if present) and returns whether x was deleted
func (c *Collection) DeleteFirst(x Ordered) bool {
	if i, ok := c.findEdge(x, -1); ok {
		*c = append((*c)[:i], (*c)[i+1:]...)
		return true
	}

	return false
}

//DeleteLast deletes last occurence of x (if present) and returns whether x was deleted
func (c *Collection) DeleteLast(x Ordered) bool {
	if i, ok := c.findEdge(x, 1); ok {
		*c = append((*c)[:i], (*c)[i+1:]...)
		return true
	}

	return false
}

//DeleteAll deletes all occurences of x (if x is present) and returns whether they were deleted
func (c *Collection) DeleteAll(x Ordered) bool {
	if left, ok := c.findEdge(x, -1); ok {
		right := left
		for (*c)[right+1] == x {
			right++
		}

		*c = append((*c)[:left], (*c)[right+1:]...)
		return true
	}

	return false
}

//findEdge finds the edge of consecutive elements that are equal to each other:
//left if step <0 is passed
//and right if step >=0 is passed
func (c *Collection) findEdge(x Ordered, step int) (mid int, ok bool) {
	step = ((step|1)&(-1<<63) + (1<<62 - 1)) / 0x3FFFFFFFFFFFFFFF

	if mid, ok = c.Find(x); ok {
		edge := 0
		back := mid //at mid's back

		if step == 1 {
			edge = len(*c) - 1
		} else {
			edge = 0
		}

		if (*c)[edge] == x {
			return edge, true
		}

		for edge-step != back {
			mid = (edge + back) / 2

			if !x.Before((*c)[mid]) && !(*c)[mid].Before(x) {
				back = mid
			} else if !x.Before((*c)[mid-step]) && !(*c)[mid-step].Before(x) {
				return mid - step, true
			} else {
				edge = mid
			}
		}
	}

	return
}

//Println prints all elements of collection and a newline
func (c Collection) Println() {
	fmt.Println(c)
}
