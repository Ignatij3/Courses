package main

import (
	"fmt"
	"math/rand"
)

func quickSortOneSide(a []int, cutoff int) {
	if len(a) <= cutoff {
		return
	}

	place := len(a) / 2
	pivot := a[place]
	a[0], a[place] = a[place], a[0]

	division := 0
	for i, x := range a {
		if x < pivot {
			division++
			a[i], a[division] = a[division], a[i]
		}
	}

	a[0], a[division] = a[division], a[0]
	quickSortOneSide(a[:division], cutoff)
	quickSortOneSide(a[division+1:], cutoff)
}
func quickSortOneSideThreePivots(a []int) {
	var lena int = len(a)

	if lena <= 2 {
		if lena == 2 && a[0] > a[1] {
			a[0], a[1] = a[1], a[0]
		}
		return
	}

	place1 := lena / 3
	place2 := lena - (lena / 3)

	pivot1 := a[place1]
	pivot2 := a[place2]

	a[0], a[place1] = a[place1], a[0]
	a[lena-1], a[place2] = a[place2], a[lena-1]

	if pivot2 < pivot1 {
		a[0], a[lena-1] = a[lena-1], a[0]
		pivot1 = a[0]
		pivot2 = a[lena-1]
	}

	div1 := 1
	div2 := lena - 2
	for {
		for a[div1] < pivot1 {
			div1++
		}
		for div2 >= 0 && a[div2] > pivot1 {
			div2--
		}

		if div1 >= div2 {
			div2 = div1 + 1
			for div1 < lena && a[div1] < pivot2 {
				div1++
			}
			for a[div2] > pivot2 {
				div2--
			}

			if div1 >= div2 {
				break
			}
			a[div1], a[div2] = a[div2], a[div1]
			div1++
			div2--
		}

		a[div1], a[div2] = a[div2], a[div1]
		div1++
		div2--
	}
	// var x int
	// for i := 1; i < lena-1; i++ {
	// 	x = a[i]
	// 	if x < pivot1 {
	// 		div1++
	// 		div2++
	// 		a[i], a[div1] = a[div1], a[i]

	// 	} else if x < pivot2 {
	// 		div2++
	// 		a[i], a[div2] = a[div2], a[i]
	// 	}
	// }

	a[0], a[div1] = a[div1], a[0]
	a[lena-1], a[div2] = a[div2], a[lena-1]
	quickSortOneSideThreePivots(a[:div1])
	quickSortOneSideThreePivots(a[div1+1 : div2])
	quickSortOneSideThreePivots(a[div2+1:])
}

func initArray(size int, state string) []int {
	rand.Seed(16)
	arr := make([]int, size)

	if state == "AlmostSorted" {
		for i := 0; i < size; i++ {
			arr[i] = i - (size / 2)
		}

		randAmt := int(float64(size) * 0.1)
		pl1, pl2 := 0, 0
		for i := 0; i < randAmt; i++ {
			pl1, pl2 = rand.Intn(size), rand.Intn(size)
			arr[pl1], arr[pl2] = arr[pl2], arr[pl1]
		}

	} else if state == "AlmostReverseSorted" {
		for i := size - 1; i >= 0; i-- {
			arr[i] = (size/2 - 1) - i
		}

		randAmt := int(float64(size) * 0.1)
		pl1, pl2 := 0, 0
		for i := 0; i < randAmt; i++ {
			pl1, pl2 = rand.Intn(size), rand.Intn(size)
			arr[pl1], arr[pl2] = arr[pl2], arr[pl1]
		}

	} else {
		for i := 0; i < size; i++ {
			arr[i] = rand.Intn(size) - size/2
		}
	}

	return arr
}

func main() {
	a := initArray(10, "")
	b := initArray(10, "")

	quickSortOneSide(a, 1)
	quickSortOneSideThreePivots(b)
	fmt.Println(a)
	fmt.Println(b)
	// fmt.Println("sorted.List")
	// sl := sorted.NewList()
	// for _, x := range []tpalias.Integer{2, 5, 7, 2, 4, 9, 1, 6} {
	// 	sl.Insert(x)
	// }
	// sl.Print()
	// fmt.Printf("\n\n")

	// fmt.Println("sortable.List")
	// al := sortable.NewList()
	// for _, x := range []tpalias.Integer{2, 5, 7, 2, 4, 9, 1, 6} {
	// 	(*al).Add(sortable.Node{Value: x, Next: *sortable.NewList()})
	// }
	// al.MergeSort()
	// al.Print()
	// fmt.Printf("\n\n")
}
