package main_test

import (
	"math/rand"
	"testing"
)

func quickSortOneSide(a []int, cutoff int) {
	if len(a) <= cutoff {
		return
	}

	place := len(a) / 2
	pivot := a[place]
	a[0], a[place] = a[place], a[0]

	division := 0
	for i, x := range a {
		if x < pivot {
			division++
			a[i], a[division] = a[division], a[i]
		}
	}

	a[0], a[division] = a[division], a[0]
	quickSortOneSide(a[:division], cutoff)
	quickSortOneSide(a[division+1:], cutoff)
}

func quickSort(a []int, cutoff int) {
	quickSortOneSide(a, cutoff)

	for i, x := range a {
		j := i
		for j > 0 && x < a[j-1] {
			a[j] = a[j-1]
			j--
		}
		a[j] = x
	}
}

func initArray(size int, state string) []int {
	rand.Seed(16)
	arr := make([]int, size)

	if state == "AlmostSorted" {
		for i := 0; i < size; i++ {
			arr[i] = i - (size / 2)
		}

		randAmt := int(float64(size) * 0.1) //percentage of random elements, 0.1 means 10% of elements are randomised
		pl1, pl2 := 0, 0
		for i := 0; i < randAmt; i++ {
			pl1, pl2 = rand.Intn(size), rand.Intn(size)
			arr[pl1], arr[pl2] = arr[pl2], arr[pl1]
		}

	} else if state == "AlmostReverseSorted" {
		for i := size - 1; i >= 0; i-- {
			arr[i] = (size/2 - 1) - i
		}

		randAmt := int(float64(size) * 0.1) //percentage of random elements, 0.1 means 10% of elements are randomised
		pl1, pl2 := 0, 0
		for i := 0; i < randAmt; i++ {
			pl1, pl2 = rand.Intn(size), rand.Intn(size)
			arr[pl1], arr[pl2] = arr[pl2], arr[pl1]
		}

	} else {
		for i := 0; i < size; i++ {
			arr[i] = rand.Intn(size) - size/2
		}
	}

	return arr
}

func Benchmark_SedgewickCutoff32_RandomArray_1000(b *testing.B) {
	arr := initArray(1000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 32)
	}
}

func Benchmark_SedgewickCutoff32_RandomArray_1000000(b *testing.B) {
	arr := initArray(1000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 32)
	}
}

func Benchmark_SedgewickCutoff32_RandomArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 32)
	}
}

func Benchmark_SedgewickCutoff32_AlmostSortedArray_1000(b *testing.B) {
	arr := initArray(1000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 32)
	}
}

func Benchmark_SedgewickCutoff32_AlmostSortedArray_1000000(b *testing.B) {
	arr := initArray(1000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 32)
	}
}

func Benchmark_SedgewickCutoff32_AlmostSortedArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 32)
	}
}

func Benchmark_SedgewickCutoff32_AlmostReverseSortedArray_1000(b *testing.B) {
	arr := initArray(1000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 32)
	}
}

func Benchmark_SedgewickCutoff32_AlmostReverseSortedArray_1000000(b *testing.B) {
	arr := initArray(1000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 32)
	}
}

func Benchmark_SedgewickCutoff32_AlmostReverseSortedArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 32)
	}
}

func Benchmark_SedgewickCutoff128_RandomArray_1000(b *testing.B) {
	arr := initArray(1000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 128)
	}
}

func Benchmark_SedgewickCutoff128_RandomArray_1000000(b *testing.B) {
	arr := initArray(1000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 128)
	}
}

func Benchmark_SedgewickCutoff128_RandomArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 128)
	}
}

func Benchmark_SedgewickCutoff128_AlmostSortedArray_1000(b *testing.B) {
	arr := initArray(1000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 128)
	}
}

func Benchmark_SedgewickCutoff128_AlmostSortedArray_1000000(b *testing.B) {
	arr := initArray(1000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 128)
	}
}

func Benchmark_SedgewickCutoff128_AlmostSortedArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 128)
	}
}

func Benchmark_SedgewickCutoff128_AlmostReverseSortedArray_1000(b *testing.B) {
	arr := initArray(1000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 128)
	}
}

func Benchmark_SedgewickCutoff128_AlmostReverseSortedArray_1000000(b *testing.B) {
	arr := initArray(1000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 128)
	}
}

func Benchmark_SedgewickCutoff128_AlmostReverseSortedArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, 128)
	}
}

func Benchmark_SedgewickCutoff16TimesLess_RandomArray_1000(b *testing.B) {
	arr := initArray(1000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, len(arr)/16)
	}
}

func Benchmark_SedgewickCutoff16TimesLess_RandomArray_1000000(b *testing.B) {
	arr := initArray(1000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, len(arr)/16)
	}
}

func Benchmark_SedgewickCutoff16TimesLess_RandomArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, len(arr)/16)
	}
}

func Benchmark_SedgewickCutoff16TimesLess_AlmostSortedArray_1000(b *testing.B) {
	arr := initArray(1000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, len(arr)/16)
	}
}

func Benchmark_SedgewickCutoff16TimesLess_AlmostSortedArray_1000000(b *testing.B) {
	arr := initArray(1000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, len(arr)/16)
	}
}

func Benchmark_SedgewickCutoff16TimesLess_AlmostSortedArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, len(arr)/16)
	}
}

func Benchmark_SedgewickCutoff16TimesLess_AlmostReverseSortedArray_1000(b *testing.B) {
	arr := initArray(1000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, len(arr)/16)
	}
}

func Benchmark_SedgewickCutoff16TimesLess_AlmostReverseSortedArray_1000000(b *testing.B) {
	arr := initArray(1000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, len(arr)/16)
	}
}

func Benchmark_SedgewickCutoff16TimesLess_AlmostReverseSortedArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSide(arr, len(arr)/16)
	}
}
