package main_test

import (
	"math/rand"
	"testing"
)

// func quickSortTwoSides(a []int) {
// 	if len(a) <= 1 {
// 		return
// 	}

// 	pivot := a[0]
// 	small, large := 1, len(a)-1
// 	for {
// 		for small < len(a) && a[small] < pivot {
// 			small++
// 		}
// 		for pivot < a[large] {
// 			large--
// 		}
// 		if small >= large {
// 			break
// 		}
// 		a[small], a[large] = a[large], a[small]
// 		small++
// 		large--
// 	}

// 	a[0], a[large] = a[large], a[0]
// 	quickSortTwoSides(a[:large])
// 	quickSortTwoSides(a[large+1:])
// }

func quickSortOneSideRandomPivot(a []int) {
	if len(a) <= 1 {
		return
	}

	place := rand.Intn(len(a))
	pivot := a[place]
	a[0], a[place] = a[place], a[0]

	division := 0
	for i, x := range a {
		if x < pivot {
			division++
			a[i], a[division] = a[division], a[i]
		}
	}

	a[0], a[division] = a[division], a[0]
	quickSortOneSideRandomPivot(a[:division])
	quickSortOneSideRandomPivot(a[division+1:])
}

func quickSortOneSideMiddlePivot(a []int) {
	if len(a) <= 1 {
		return
	}

	place := len(a) / 2
	pivot := a[place]
	a[0], a[place] = a[place], a[0]

	division := 0
	for i, x := range a {
		if x < pivot {
			division++
			a[i], a[division] = a[division], a[i]
		}
	}

	a[0], a[division] = a[division], a[0]
	quickSortOneSideMiddlePivot(a[:division])
	quickSortOneSideMiddlePivot(a[division+1:])
}

func initArray(size int, state string) []int {
	rand.Seed(16)
	arr := make([]int, size)

	if state == "AlmostSorted" {
		for i := 0; i < size; i++ {
			arr[i] = i - (size / 2)
		}

		randAmt := int(float64(size) * 0.1) //percentage of random elements, 0.1 means 10% of elements are randomised
		pl1, pl2 := 0, 0
		for i := 0; i < randAmt; i++ {
			pl1, pl2 = rand.Intn(size), rand.Intn(size)
			arr[pl1], arr[pl2] = arr[pl2], arr[pl1]
		}

	} else if state == "AlmostReverseSorted" {
		for i := size - 1; i >= 0; i-- {
			arr[i] = (size/2 - 1) - i
		}

		randAmt := int(float64(size) * 0.1) //percentage of random elements, 0.1 means 10% of elements are randomised
		pl1, pl2 := 0, 0
		for i := 0; i < randAmt; i++ {
			pl1, pl2 = rand.Intn(size), rand.Intn(size)
			arr[pl1], arr[pl2] = arr[pl2], arr[pl1]
		}

	} else {
		for i := 0; i < size; i++ {
			arr[i] = rand.Intn(size) - size/2
		}
	}

	return arr
}

func Benchmark_RandomPivot_RandomArray_1000(b *testing.B) {
	arr := initArray(1000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideRandomPivot(arr)
	}
}

func Benchmark_RandomPivot_RandomArray_1000000(b *testing.B) {
	arr := initArray(1000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideRandomPivot(arr)
	}
}

func Benchmark_RandomPivot_RandomArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideRandomPivot(arr)
	}
}

func Benchmark_MiddlePivot_RandomArray_1000(b *testing.B) {
	arr := initArray(1000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideMiddlePivot(arr)
	}
}

func Benchmark_MiddlePivot_RandomArray_1000000(b *testing.B) {
	arr := initArray(1000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideMiddlePivot(arr)
	}
}

func Benchmark_MiddlePivot_RandomArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideMiddlePivot(arr)
	}
}

func Benchmark_RandomPivot_AlmostSortedArray_1000(b *testing.B) {
	arr := initArray(1000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideRandomPivot(arr)
	}
}

func Benchmark_RandomPivot_AlmostSortedArray_1000000(b *testing.B) {
	arr := initArray(1000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideRandomPivot(arr)
	}
}

func Benchmark_RandomPivot_AlmostSortedArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideRandomPivot(arr)
	}
}

func Benchmark_MiddlePivot_AlmostSortedArray_1000(b *testing.B) {
	arr := initArray(1000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideMiddlePivot(arr)
	}
}

func Benchmark_MiddlePivot_AlmostSortedArray_1000000(b *testing.B) {
	arr := initArray(1000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideMiddlePivot(arr)
	}
}

func Benchmark_MiddlePivot_AlmostSortedArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "AlmostSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideMiddlePivot(arr)
	}
}

func Benchmark_RandomPivot_AlmostReverseSortedArray_1000(b *testing.B) {
	arr := initArray(1000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideRandomPivot(arr)
	}
}

func Benchmark_RandomPivot_AlmostReverseSortedArray_1000000(b *testing.B) {
	arr := initArray(1000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideRandomPivot(arr)
	}
}

func Benchmark_RandomPivot_AlmostReverseSortedArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideRandomPivot(arr)
	}
}

func Benchmark_MiddlePivot_AlmostReverseSortedArray_1000(b *testing.B) {
	arr := initArray(1000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideMiddlePivot(arr)
	}
}

func Benchmark_MiddlePivot_AlmostReverseSortedArray_1000000(b *testing.B) {
	arr := initArray(1000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideMiddlePivot(arr)
	}
}

func Benchmark_MiddlePivot_AlmostReverseSortedArray_1000000000(b *testing.B) {
	arr := initArray(1000000000, "AlmostReverseSorted")
	b.ResetTimer()

	for i := 0; i < b.N; i++ {
		quickSortOneSideMiddlePivot(arr)
	}
}
