package sortable

import (
	"fmt"
	"math/rand"

	order ".."
)

//Collection is an alias to slice of Ordered
type Collection []order.Ordered

//NewCollection Creates new empty collection
func NewCollection() Collection {
	return []order.Ordered{}
}

const cutoff = 32

func (c Collection) qSort() {
	if len(c) <= cutoff {
		return
	}

	k := rand.Intn(len(c))
	c[0], c[k] = c[k], c[0]

	pivot := c[0]
	small, large := 1, len(c)-1
	for {
		for small < len(c) && c[small].Before(pivot) {
			small++
		}
		for pivot.Before(c[large]) {
			large--
		}
		if small >= large {
			break
		}
		c[small], c[large] = c[large], c[small]
		small++
		large--
	}

	c[0], c[large] = c[large], c[0]
	c[:large].qSort()
	c[large+1:].qSort()
}

//QSort sorts Collection using quick sort
func (c Collection) QSort() {
	c.qSort()
	for i, x := range c {
		j := i
		for j > 0 && x.Before(c[j-1]) {
			c[j] = c[j-1]
			j--
		}
		c[j] = x
	}
}

func (c Collection) merge(start2 int) {
	res := make([]order.Ordered, len(c))
	i1, i2, ires := 0, start2, 0
	for i1 < start2 && i2 < len(c) {
		if c[i1].Before(c[i2]) {
			res[ires] = c[i1]
			i1++
		} else {
			res[ires] = c[i2]
			i2++
		}
		ires++
	}
	if i2 == len(c) {
		copy(c[ires:], c[i1:])
	}
	copy(c, res[:ires])
}

//BinaryMergeSort sorts Collection using binary merge sort
func (c Collection) BinaryMergeSort() {
	var mid int
	for currSize := 1; currSize <= len(c)-1; currSize = 2 * currSize {
		for leftStart := 0; leftStart < len(c)-1; leftStart += 2 * currSize {
			mid = leftStart + currSize - 1
			if mid > len(c)-1 {
				mid = len(c) - 1
			}
			c.merge(mid + 1)
		}
	}

	c.merge(len(c) / 2)
}

//NaturalMergeSort sorts Collection using natural merge sort
func (c Collection) NaturalMergeSort() {
	// инициализация - заполняем слайс start
	start := []int{0}
	for i := 1; i < len(c); i++ {
		if c[i].Before(c[i-1]) {
			start = append(start, i)
		}
	}
	start = append(start, len(c))
	// сортировка
	for len(start) > 2 {
		// проходим по всему массиву, склеивая пары соседних серий
		for k := 0; k < len(start)-2; k += 2 {
			c[start[k]:start[k+2]].merge(start[k+1] - start[k])
		}
		// преобразуем слайс start: start[2] -> start[1],
		// start[4] -> start[2], start[6] -> start[3] и т.д.
		k := 0
		for {
			k += 2
			if k >= len(start) {
				break
			}
			start[k/2] = start[k]
		}
		start = start[:k/2]
		// если перед этим было нечётное количество серий, то
		// надо добавить конец последней серии - len(l)
		if start[len(start)-1] < len(c) {
			start = append(start, len(c))
		}
	}
}

//Print prints all elements of Collection
func (c Collection) Print() {
	for _, x := range c {
		fmt.Print(x.Show())
	}
}

type (
	//Node holds value and pointer to next element
	Node struct {
		Value order.Ordered
		Next  List
	}
	//List holds pointer to first value
	List struct {
		First *Node
	}
)

//Before returns whether n must stand before b in sorted list
func (n Node) Before(b order.Ordered) bool {
	return n.Value.Before(b.(Node).Value)
}

//Show returns string representation of underlying value
func (n Node) Show() string {
	return n.Value.Show()
}

//NewList returns pointer to the new empty list
func NewList() *List {
	return &List{}
}

//IsEmpty returns whether List is empty
func (s List) IsEmpty() bool {
	return s.First == nil
}

//Add prepends x to List
func (s *List) Add(x Node) {
	x.Next = *s
	(*s).First = &x
}

//QSort sorts List using quick sort
func (s *List) QSort() {
	if (*s).IsEmpty() || (*(*s).First).Next.IsEmpty() {
		return
	}
	pivotNode := *(*s).First // var pivotNode Node
	a1, a2 := (*(*s).First).Next.separateByPivot(pivotNode)
	a1.QSort()
	a2.QSort()
	pivotNode.Next = a2
	a2.First = &pivotNode
	var runner List
	if a1.IsEmpty() {
		*s = a2
	} else {
		runner = a1
		for !(*runner.First).Next.IsEmpty() {
			runner = (*runner.First).Next
		}
		(*runner.First).Next = a2
		*s = a1
	}
}

func (s List) separateByPivot(pivot order.Ordered) (List, List) {
	runner := s // var runner List
	var next List
	a1, a2 := *NewList(), *NewList()
	for !runner.IsEmpty() {
		next = (*runner.First).Next // <==>  next = (*(runner.First)).Next
		if (*runner.First).Before(pivot) {
			(*runner.First).Next = a1
			a1 = runner
		} else {
			(*runner.First).Next = a2
			a2 = runner
		}
		runner = next
	}
	return a1, a2
}

//MergeSort sorts Collection using basic merge sort
func (s *List) MergeSort() {
	if (*s).IsEmpty() || (*(*s).First).Next.IsEmpty() {
		return
	}
	a1, a2 := *s, (*s.First).Next
	for !a2.IsEmpty() && !(*a2.First).Next.IsEmpty() {
		a1 = (*a1.First).Next
		a2 = (*(*a2.First).Next.First).Next
	}
	a2, (*a1.First).Next, a1 = (*a1.First).Next, List{nil}, *s
	a1.MergeSort()
	a2.MergeSort()
	*s = merge(a1, a2)
}

func merge(a List, b List) List {
	if a.IsEmpty() {
		return b
	}
	if b.IsEmpty() {
		return a
	}
	var res List
	if (*a.First).Value.Before((*b.First).Value) {
		res, a = a, (*a.First).Next
	} else {
		res, b = b, (*b.First).Next
	}
	runner := res.First
	for !a.IsEmpty() && !b.IsEmpty() {
		if (*a.First).Value.Before((*b.First).Value) {
			(*runner).Next, a = a, (*a.First).Next
		} else {
			(*runner).Next, b = b, (*b.First).Next
		}
		runner = (*runner).Next.First
	}
	if a.IsEmpty() {
		(*runner).Next = b
	} else {
		// b.IsEmpty()
		(*runner).Next = a
	}
	return res
}

//Print prints all elements of List
func (s List) Print() {
	if s.IsEmpty() {
		return
	}

	fmt.Printf("%s ", (*s.First).Show())
	for elem := s.First.Next; elem.First != nil; elem = elem.First.Next {
		fmt.Printf("%s ", elem.First.Show())
	}
}
