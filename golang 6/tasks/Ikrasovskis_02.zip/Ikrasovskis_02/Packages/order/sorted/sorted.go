package sorted

import (
	"fmt"

	order ".."
)

//Collection is an alias to the type []order.Ordered
type Collection []order.Ordered

//Insert inserts new element into collection, using binary search
func (c *Collection) Insert(x order.Ordered) {
	left := 0
	mid := 0
	right := len(*c) - 1

	for left <= right {
		mid = (right + left) / 2

		if x.Before((*c)[mid]) {
			right = mid - 1
			if left > right {
				break
			}

		} else if (*c)[mid].Before(x) {
			left = mid + 1
			if left > right {
				mid++
				break
			}

		} else {
			break
		}
	}

	*c = append(*c, x)
	copy((*c)[mid+1:], (*c)[mid:])
	(*c)[mid] = x
}

//Find returns position of the found element to the one provided and whether it was found
func (c *Collection) Find(x order.Ordered) (int, bool) {
	left := 0
	mid := 0
	right := len(*c) - 1

	if len(*c) == 0 || x.Before((*c)[left]) || (*c)[right].Before(x) {
		return 0, false
	} else if (*c)[left] == x {
		return right, true
	}

	for left <= right {
		mid = (right + left) / 2

		if x.Before((*c)[mid]) {
			right = mid - 1

		} else if (*c)[mid].Before(x) {
			left = mid + 1

		} else {
			return mid, true
		}
	}

	return 0, false
}

//First returns position of the first found equivalent element to the one provided and whether it was found
func (c *Collection) First(x order.Ordered) (index int, detected bool) {
	return c.findEdge(x, -1)
}

//Last returns position of the last found equivalent element to the one provided and whether it was found
func (c *Collection) Last(x order.Ordered) (index int, detected bool) {
	return c.findEdge(x, 1)
}

//DeleteFirst deletes first occurence of x (if present) and returns whether x was deleted
func (c *Collection) DeleteFirst(x order.Ordered) bool {
	if i, ok := c.findEdge(x, -1); ok {
		*c = append((*c)[:i], (*c)[i+1:]...)
		return true
	}

	return false
}

//DeleteLast deletes last occurence of x (if present) and returns whether x was deleted
func (c *Collection) DeleteLast(x order.Ordered) bool {
	if i, ok := c.findEdge(x, 1); ok {
		*c = append((*c)[:i], (*c)[i+1:]...)
		return true
	}

	return false
}

//DeleteAll deletes all occurences of x (if x is present) and returns whether they were deleted
func (c *Collection) DeleteAll(x order.Ordered) bool {
	if left, ok := c.findEdge(x, -1); ok {
		right := left
		for (*c)[right+1] == x {
			right++
		}

		*c = append((*c)[:left], (*c)[right+1:]...)
		return true
	}

	return false
}

//findEdge finds the edge of consecutive elements that are equal to each other:
//left if step <0 is passed
//and right if step >=0 is passed
func (c *Collection) findEdge(x order.Ordered, step int) (mid int, ok bool) {
	step = (step >> 63) | 1

	if mid, ok = c.Find(x); ok {
		edge := 0
		back := mid //at mid's back

		if step == 1 {
			edge = len(*c) - 1
		} else {
			edge = 0
		}

		if (*c)[edge] == x {
			return edge, true
		}

		for edge-step != back {
			mid = (edge + back) / 2

			if !x.Before((*c)[mid]) && !(*c)[mid].Before(x) {
				back = mid
			} else if !x.Before((*c)[mid-step]) && !(*c)[mid-step].Before(x) {
				return mid - step, true
			} else {
				edge = mid
			}
		}
	}

	return
}

//Print prints all elements of the collection
func (c Collection) Print() {
	for _, x := range c {
		fmt.Print(x.Show())
	}
}

type (
	//List implements linked list with key of type Ordered
	List struct {
		First *Node
	}
	//Node holds value and pointer to next node
	Node struct {
		Key  order.Ordered
		Tail *Node
	}
)

//NewList creates empty List
func NewList() *List {
	return &List{}
}

//IsEmpty returns whether List is empty
func (s List) IsEmpty() bool {
	return s.First == nil
}

//Insert inserts x in the List, so that x is less than next element
func (s *List) Insert(x order.Ordered) {
	if s.First == nil {
		s.First = &Node{Key: x, Tail: nil}
		return
	}

	//nodepp это указатель на указатель на Node потому что
	//таким образом можно менять указатель на Node там, где он хранится
	for nodepp := &s.First; ; nodepp = &(*nodepp).Tail {
		if (*nodepp).Tail == nil {
			(*nodepp).Tail = &Node{Key: x, Tail: nil}
			break
		}

		if !(*nodepp).Key.Before(x) {
			*nodepp = &Node{Key: x, Tail: *nodepp}
			break
		}
	}
}

//Print prints all elements of the List
func (s List) Print() {
	if s.IsEmpty() {
		return
	}

	for elem := s.First; elem != nil; elem = elem.Tail {
		fmt.Printf("%s ", elem.Key.Show())
	}
}
