package order

//Ordered is an interface for managing ordered lists
type Ordered interface {
	Before(b Ordered) bool
	Show() string
}
