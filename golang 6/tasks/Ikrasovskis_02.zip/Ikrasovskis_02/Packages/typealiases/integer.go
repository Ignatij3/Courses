package typealiases

import (
	"fmt"

	"../order"
)

//Integer is an alias for built-in type int
type Integer int

//Before returns whether i is less than b (of underlying type Integer)
func (i Integer) Before(b order.Ordered) bool {
	return i < b.(Integer)
}

//Show returns string representation of underlying value
func (i Integer) Show() string {
	return fmt.Sprintf("%d", i)
}
