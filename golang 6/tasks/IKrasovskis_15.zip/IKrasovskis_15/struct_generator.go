package main

import (
	"fmt"
	"os"
	"strings"
)

const MAX_ROMAN = 3999

var numeral = []int{1000, 500, 100, 50, 10, 5, 1}

// Допустим, оно работает верно
func decToRoman(n int) (roman string) {
	var letter string

	for _, v := range numeral {
		switch v {
		case 1000:
			letter = "M"
		case 500:
			letter = "D"
		case 100:
			letter = "C"
		case 50:
			letter = "L"
		case 10:
			letter = "X"
		case 5:
			letter = "V"
		case 1:
			letter = "I"
		}
		for n >= v {
			n -= v
			roman += letter
		}
	}

	roman = strings.Replace(roman, "DCCCC", "CM", 1)
	roman = strings.Replace(roman, "CCCC", "CD", 1)
	roman = strings.Replace(roman, "LXXXX", "XC", 1)
	roman = strings.Replace(roman, "XXXX", "XL", 1)
	roman = strings.Replace(roman, "VIIII", "IX", 1)
	roman = strings.Replace(roman, "IIII", "IV", 1)

	return roman
}

func generateNumerals() (numerals [MAX_ROMAN]string) {
	for i := 0; i < MAX_ROMAN; i++ {
		numerals[i] = decToRoman(i + 1)
	}
	return
}

func generateStructure(numerals [MAX_ROMAN]string) string {
	var result string = `package roman
import "testing"

var validTests = []struct {
	input    string
	expected int
}{
`
	for num, roman := range numerals {
		result += fmt.Sprintf("\t{\"%s\", %d},\n", roman, num+1)
	}

	result += `}

var invalidTests = []string{
	"",
	"IIX",
	"IIII",
	"VV",
	"VX",
	"XXXX",
	"LL",
	"LC",
	"CCCC",
	"DD",
	"DM",
	"Z",
	"ZI",
	"IZ",
	"123",
	"@",
	"MMMM",
}

func TestValid(t *testing.T) {
	for _, tt := range validTests {
		res, err := RomanToDec(tt.input)
		if err != nil {
			t.Errorf("Unexpected error for input %v: %v", tt.input, err)
		}
		if res != tt.expected {
			t.Errorf("Unexpected value for input %v: %v", tt.input, res)
		}
	}
}

func TestInvalid(t *testing.T) {
	for _, tt := range invalidTests {
		res, err := RomanToDec(tt)
		if err == nil {
			t.Errorf("Expected error for input %v but received %v", tt, res)
		}
		if err != ErrInvalidFormat {
			t.Errorf("Unexpected error for input %v: %v", tt, err)
		}
	}
}
`
	return result
}

func main() {
	numerals := generateNumerals()
	structure := generateStructure(numerals)
	os.WriteFile("roman_test.go", []byte(structure), 0777)
}
