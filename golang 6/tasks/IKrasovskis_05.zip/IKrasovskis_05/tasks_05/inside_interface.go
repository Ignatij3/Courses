package main

import (
	"fmt"
	"reflect"
	"strconv"
	"strings"
	"unsafe"
)

//Структура, которой реализуется пустой interface{}
type eface struct {
	_type *_type
	data  unsafe.Pointer
}

//Вставил сюда, чтобы было к чему тайпкастить
type _type struct {
	size       uintptr
	ptrdata    uintptr // size of memory prefix holding all pointers
	hash       uint32
	tflag      tflag
	align      uint8
	fieldAlign uint8
	kind       uint8
	// function for comparing objects of this type
	// (ptr to object A, ptr to object B) -> ==?
	equal func(unsafe.Pointer, unsafe.Pointer) bool
	// gcdata stores the GC type data for the garbage collector.
	// If the KindGCProg bit is set in kind, gcdata is a GC program.
	// Otherwise it is a ptrmask bitmap. See mbitmap.go for details.
	gcdata    *byte
	str       nameOff
	ptrToThis typeOff
}

//Оставил оригинальные alias'ы
type tflag uint8
type nameOff int32
type typeOff int32

/*
Эта функция вызывается при выводе интерфейса с использованием print()
func printeface(e eface) {
	print("(", e._type, ",", e.data, ")")
}
*/

//Обычная структура
type building struct {
	floors    uint
	bathrooms uint8
	street    string
}

//Выводит результат функции, если в eface находится невалидное значение - появляется ошибка
func testFunction(myeface eface) {
	var (
		test1, test2 int            = 1, 1
		t1ptr, t2ptr unsafe.Pointer = unsafe.Pointer(&test1), unsafe.Pointer(&test2)
	)

	fmt.Printf("(should be true): %t\n", myeface._type.equal(t1ptr, t1ptr))
	fmt.Printf("(should be false): %t\n", myeface._type.equal(t1ptr, t2ptr))
}

//Достаю структуру, на которой лежит переданный interface{}, с помощью выведенных указателей на данные
//Необходим ввод адресов от пользователя (адреса будут предоставлены)
func getInterfaceInternalsManual(iface interface{}) eface {
	//Вывожу адреса полей структуры интерфейса
	println(iface)

	//Прошу пользователя ввести выведеные ранее адреса и следующие 22 строки парсю введёные пользователем адреса
	//(https://ru.wiktionary.org/wiki/%D0%BF%D0%B0%D1%80%D1%81%D0%B8%D1%82%D1%8C)
	var addr []byte
	fmt.Printf("Enter addresses above: ")
	fmt.Scan(&addr)

	if addr[0] == '(' {
		addr = addr[1:]
	}
	if addr[len(addr)-1] == ')' {
		addr = addr[:len(addr)-1]
	}
	addreses := strings.Split(string(addr), ",")

	adr1, err := strconv.ParseUint(addreses[0], 0, 64)
	if err != nil {
		panic(err)
	}

	adr2, err := strconv.ParseUint(addreses[1], 0, 64)
	if err != nil {
		panic(err)
	}

	//Привожу полученные указатели в нужные типы данных, чтобы их можно было использовать
	val1 := (*_type)(unsafe.Pointer(uintptr(adr1)))
	myeface := eface{_type: val1, data: unsafe.Pointer(uintptr(adr2))}

	return myeface
}

func getDataptrptr(iface interface{}) *unsafe.Pointer {
	value := reflect.ValueOf(iface)

	//Нахожу указатель на unsafe.Pointer, который указывает на unsafe.Pointer, который указывает на данные, которые лежат в переданном интерфейсе
	//offset равен 8-и потому-что указатель 2-й по очереди и находится после *rtype, который занимает 8 байт
	ptr := unsafe.Pointer(unsafe.Add(unsafe.Pointer(&value), 8))

	return (*unsafe.Pointer)(ptr)
}

//Достаю структуру, на которой лежит переданный interface{}, с помощью пакета reflect
func getInterfaceInternalsAutomatic(iface interface{}) eface {
	datapp := getDataptrptr(iface)

	//Перемещаю datapp на указатель на _type
	//offset равен -8 потому-что указатель, на который я перемещаю datapp занимает 8 байт
	typepp := unsafe.Add(unsafe.Pointer(datapp), -8)

	return eface{_type: *(**_type)(typepp), data: unsafe.Pointer(*datapp)}
}

//Возвращает копию структуры интерфейса, которая основана на переданном интерфейсе
//Возвращённое значение не привязано ни к какому настоящему интерфейсу
func copyAndAssignData(myeface eface, newData interface{}) eface {
	datapp := getDataptrptr(newData)

	return eface{_type: myeface._type, data: unsafe.Pointer(*datapp)}
}

func main() {
	var iface interface{}
	home := building{
		floors:    12,
		bathrooms: 2,
		street:    "maskachkas iela 42/0",
	}

	iface = home
	fmt.Printf("Interface data: %v\n\n", iface)

	myeface := getInterfaceInternalsAutomatic(iface)
	// myeface := getInterfaceInternalsManual(iface)

	//Нужно type-cast'ить к тому типу, на который указывает data (который сунули в интерфейс)
	underlyingdata := *(*building)(myeface.data)
	fmt.Printf("_type: %v\ndata: %v\n\n", *myeface._type, underlyingdata)

	//По идее, если я привёл _type не к настоящему месту в памяти,
	//то ошибка должна была случиться уже в предыдущем fmt.Printf(),
	//но я оставил вызов функции, что-бы быть уверенным наверняка
	testFunction(myeface)

	neface := copyAndAssignData(myeface, "abcdefghijklmnopqrstuvwxyz")

	fmt.Printf("new (string) data: %s\n", *(*string)(neface.data))
}
