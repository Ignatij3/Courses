package main

import (
	"fmt"
	"math"

	"projectname/dirlist"
)

func main() {
	list := dirlist.NewDirectedList()

	for i := 0; i < 11; i++ {
		list.PushBack(i)
	}

	fmt.Println("new list:")
	list.Traverse(func(v interface{}) { fmt.Printf("%v ", v) })

	list.InsertAfter(math.MinInt64, func(v interface{}) bool { return v.(int) >= 5 })

	fmt.Println("list after insertAfter:")
	list.Traverse(func(v interface{}) { fmt.Printf("%v ", v) })

	list.DeleteAfter(func(v interface{}) bool { return v.(int)%3 == 0 })

	fmt.Println("list after deleteAfter:")
	list.Traverse(func(v interface{}) { fmt.Printf("%v ", v) })

	fmt.Println("list elements which are divided by 2:")
	list.TraverseIf(func(v interface{}) { fmt.Printf("%v ", v) }, func(v interface{}) bool { return v.(int)%2 == 0 })

}
