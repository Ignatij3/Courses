package main

import (
	"fmt"
	// "math/rand"
	// "time"
	"alphaBetaGammaDeltaEpsilonZetaEtaThetaIotaKappaLambdaMuNuXiOmicronPiRhoSigmaTauUpsilonPhiChiPsiOmegaSexyStuff/skiplist"
)

func main() {
	list := skiplist.NewSkipList(14, 0.7, func(a, b interface{}) bool {
		return a.(int) > b.(int)
	})

	show := func(v interface{}) { fmt.Printf("%d ", v) }

	list.Insert(2)
	list.Traverse(show)
	fmt.Println()
	list.Insert(4)
	list.Traverse(show)
	fmt.Println()
	list.Insert(1)
	list.Insert(8)
	list.Insert(5)
	list.Traverse(show)
	fmt.Println()

	list.Remove(5)
	list.Traverse(show)
	fmt.Println()
	list.Remove(8)
	list.Traverse(show)
	fmt.Println()
	list.Remove(1)
	list.Traverse(show)
	fmt.Println()
}
