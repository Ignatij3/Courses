package skiplist

import (
	"math/rand"
)

type signed interface {
	~int | ~int8 | ~int16 | ~int32 | ~int64
}

type unsigned interface {
	~uint | ~uint8 | ~uint16 | ~uint32 | ~uint64 | ~uintptr
}

type integer interface {
	signed | unsigned
}

type float interface {
	~float32 | ~float64
}

type ordered interface {
	integer | float | ~string
}

type SkipListNodeGeneric[T ordered] struct {
	next  []*SkipListNodeGeneric[T]
	value T
}

func (u *SkipListNodeGeneric[T]) Value() T {
	return u.value
}

func (u *SkipListNodeGeneric[T]) level() int {
	return len(u.next) - 1
}

type SkipListGeneric[T ordered] struct {
	head     *SkipListNodeGeneric[T]
	maxLevel int
	topLevel int
	p        float64
	less     func(T, T) bool
}

func NewSkipListGeneric[T ordered](maxLevel int, p float64, less func(T, T) bool) SkipListGeneric[T] {
	return SkipListGeneric[T]{head: &SkipListNodeGeneric[T]{next: make([]*SkipListNodeGeneric[T], maxLevel+1)}, maxLevel: maxLevel, topLevel: 0, p: p, less: less}
}

func (t *SkipListGeneric[T]) Insert(v T) {
	l := t.newNodeLevel()
	node := &SkipListNodeGeneric[T]{value: v, next: make([]*SkipListNodeGeneric[T], l+1)}

	u := t.head
	for level := node.level(); level >= 0; level-- {
		for {
			if t.before((*u).next[level], node) {
				u = (*u).next[level]
			} else {
				(*node).next[level] = (*u).next[level]
				(*u).next[level] = node
				break
			}
		}
	}
}

func (t SkipListGeneric[T]) before(u *SkipListNodeGeneric[T], v *SkipListNodeGeneric[T]) bool { // u << v
	if v == nil {
		return true
	} // v is tail node
	if u == nil {
		return false
	} // u is tail node
	return t.less(u.Value(), v.Value())
}

func (t *SkipListGeneric[T]) newNodeLevel() int {
	res := 0
	for rand.Float64() < t.p && res <= t.topLevel && res < t.maxLevel {
		res++
	}
	if res > t.topLevel {
		t.topLevel = res
	}
	return res
}
