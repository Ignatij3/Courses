package skiplist

import (
	"math/rand"
)

type SkipListNode struct {
	next  []*SkipListNode
	value any
}

func (u *SkipListNode) Value() any {
	return u.value
}

func (u *SkipListNode) level() int {
	return len(u.next) - 1
}

type SkipList struct {
	head     *SkipListNode
	maxLevel int
	topLevel int
	p        float64
	less     func(any, any) bool
}

type SkipListInt struct {
	SkipList
}

func NewSkipList(maxLevel int, p float64, less func(any, any) bool) SkipList {
	return SkipList{head: &SkipListNode{next: make([]*SkipListNode, maxLevel+1)}, maxLevel: maxLevel, topLevel: 0, p: p, less: less}
}

func NewSkipListInt(maxLevel int, p float64, less func(int, int) bool) SkipListInt {
	return SkipListInt{
		SkipList: NewSkipList(maxLevel, p, func(a, b any) bool {
			return less(a.(int), b.(int))
		}),
	}
}

func (t *SkipList) Insert(v any) {
	l := t.newNodeLevel()
	node := &SkipListNode{value: v, next: make([]*SkipListNode, l+1)}

	u := t.head
	for level := node.level(); level >= 0; level-- {
		for {
			if t.before((*u).next[level], node) {
				u = (*u).next[level]
			} else {
				(*node).next[level] = (*u).next[level]
				(*u).next[level] = node
				break
			}
		}
	}
}

func (t *SkipListInt) Insert(v int) {
	t.SkipList.Insert(v)
}

func (t SkipList) before(u *SkipListNode, v *SkipListNode) bool { // u << v
	if v == nil {
		return true
	} // v is tail node
	if u == nil {
		return false
	} // u is tail node
	return t.less(u.Value(), v.Value())
}

func (t *SkipList) newNodeLevel() int {
	res := 0
	for rand.Float64() < t.p && res <= t.topLevel && res < t.maxLevel {
		res++
	}
	if res > t.topLevel {
		t.topLevel = res
	}
	return res
}
