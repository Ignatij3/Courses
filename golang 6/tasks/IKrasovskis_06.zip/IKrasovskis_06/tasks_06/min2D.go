package main

import (
	"fmt"
	"math"
	"sort"
)

type (
	Function1D func(float64) float64
	Function2D func(float64, float64) float64
)

func minimum2D(left, right, bottom, top float64, F2 Function2D) (float64, float64) {
	h := (func(x float64) float64 {
		q := (func(y float64) float64 {
			return F2(x, y)
		})
		ymin := minimum1D(bottom, top, q)
		return F2(x, ymin)
	})

	xmin := minimum1D(left, right, h)
	ymin := minimum1D(bottom, top, func(y float64) float64 { return f(xmin, y) })
	return xmin, ymin
}

func minimum1D(start, finish float64, F1 Function1D) float64 {
	var pmin float64

	epsilon := 1e-9
	req := func(i int) bool {
		fl := float64(i)
		return F1(fl-epsilon) > F1(fl) && F1(fl) < F1(fl+epsilon)
	}

	pmin = float64(sort.Search(int(finish-start), req))
	return start + pmin*epsilon
}

func f(x, y float64) float64 {
	return math.Sin(x)/(0.05*x) + math.Sin(y)/(0.05*y)
}

func main() {
	var left, right, bottom, top float64
	left, right, bottom, top = 10, 100, -100, 100
	fmt.Println(minimum2D(left, right, bottom, top, f))
}
