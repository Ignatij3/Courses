package main

import "fmt"

func makePanic() {
	panic("s[p]asi")
}

func deferWithPanic() {
	defer dealWithPanic(0)
	defer makePanic()
	fmt.Println("defer ended it's life successfully")
	defer dealWithPanic(1)
}

func dealWithPanic(id int) {
	fmt.Printf("recover func id: %d - ", id)
	if rec := recover(); rec != nil {
		fmt.Printf("recovered from: %v\n", rec)
	} else {
		fmt.Println("no panic caught")
	}
}

func raisePanic() {
	defer dealWithPanic(2)
	defer dealWithPanic(3)
	defer deferWithPanic()
	err := make([]int, 0)
	print(err[0])
}

func main() {
	raisePanic()
	fmt.Println("successful finish")
}
