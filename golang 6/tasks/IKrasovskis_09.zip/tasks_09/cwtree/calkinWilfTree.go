package cwtree

import (
	btr "container/binarytree"
	"fmt"
	"strings"

	"../fraction"
)

//CalkinWilfTree is a calkin-wilf tree
type CalkinWilfTree struct {
	frac   fraction.Fraction
	layers uint64
	tree   *btr.BSTree
}

//NewCWTree creates a new calkin-wilf tree
func NewCWTree(a, b uint64) *CalkinWilfTree {
	less := func(x interface{}, y interface{}) bool {
		return x.(fraction.Fraction).Num < y.(fraction.Fraction).Num
	}
	t := btr.NewBSTree(less)

	return &CalkinWilfTree{frac: fraction.NewFraction(a, b), layers: 0, tree: &t}
}

//Extend adds 1 more layer to a tree
func (c *CalkinWilfTree) Extend() {
	if c.tree.Empty() {
		c.tree.Insert(fraction.NewFraction(c.frac.Num, c.frac.Denom))
		c.layers = 1
		return
	}

	if c.tree.Left().Empty() {
		c.tree.Left().Insert(fraction.NewFraction(c.tree.Value().(fraction.Fraction).Num, c.tree.Value().(fraction.Fraction).Num+c.tree.Value().(fraction.Fraction).Denom))
	} else {
		copy := c.tree
		c.tree = c.tree.Left()
		c.Extend()
		c.tree = copy
	}

	if c.tree.Right().Empty() {
		c.tree.Right().Insert(fraction.NewFraction(c.tree.Value().(fraction.Fraction).Num+c.tree.Value().(fraction.Fraction).Denom, c.tree.Value().(fraction.Fraction).Denom))
	} else {
		copy := c.tree
		c.tree = c.tree.Right()
		c.Extend()
		c.tree = copy
	}
}

//ToString returns a string representation of a tree
func (c CalkinWilfTree) ToString() string {
	show := func(x interface{}) string {
		return fmt.Sprintf("%d/%d", x.(fraction.Fraction).Num, x.(fraction.Fraction).Denom)
	}

	var builder strings.Builder
	strlist := c.tree.Diagram(show)

	for _, str := range strlist {
		builder.WriteString(str)
		builder.WriteByte('\n')
	}

	return builder.String()
}
