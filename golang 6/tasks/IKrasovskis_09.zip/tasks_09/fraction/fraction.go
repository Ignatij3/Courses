package fraction

// Fraction is a mathematical fraction
type Fraction struct {
	Num   uint64
	Denom uint64
}

// NewFraction creates a new fraction
func NewFraction(a uint64, b uint64) Fraction {
	return Fraction{Num: a, Denom: b}
}
