package main

import (
	"fmt"
	"os"

	"./cwtree"
)

func promptData() (num, denom uint64, depth int) {
	fmt.Print("Enter fraction numerator: ")
	fmt.Scanf("%d\n", &num)
	for num == 0 {
		fmt.Println("Numerator cannot be 0")
		fmt.Print("Enter fraction numerator: ")
		fmt.Scanf("%d\n", &num)
	}

	fmt.Print("Enter fraction denominator: ")
	fmt.Scanf("%d\n", &denom)
	for denom == 0 {
		fmt.Println("Denominator cannot be 0")
		fmt.Print("Enter fraction denominator: ")
		fmt.Scanf("%d\n", &denom)
	}

	fmt.Print("Enter tree depth, in layers: ")
	fmt.Scanf("%d\n", &depth)
	for depth < 1 {
		fmt.Println("Depth must be at least 1")
		fmt.Print("Enter tree depth, in layers: ")
		fmt.Scanf("%d\n", &depth)
	}

	return num, denom, depth
}

func writeToFile(s string) {
	fmt.Print("Enter file name: ")
	var fileName string
	fmt.Scanf("%s\n", &fileName)

	file, err := os.Create(fileName)
	if err != nil {
		fmt.Println("Error creating file")
		return
	}

	defer file.Close()

	file.WriteString(s)
}

func main() {
	num, denom, depth := promptData()

	cwtree := cwtree.NewCWTree(num, denom)
	for i := 0; i < depth; i++ {
		cwtree.Extend()
	}

	writeToFile(cwtree.ToString())
}
